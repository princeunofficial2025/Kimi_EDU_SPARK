import { useState, useEffect, useCallback, useMemo } from 'react';
import type { Student, Alert, RiskMetrics, SystemStatus } from '@/types';
import { generateStudents, generateAlerts } from '@/data/mockData';

export function useStudents() {
  const [students, setStudents] = useState<Student[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<'all' | 'low' | 'medium' | 'high'>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    isOnline: true,
    lastSync: new Date(),
    modelVersion: 'v2.4.1',
    accuracy: 94.7,
    predictionsToday: 0
  });

  // Initialize data
  useEffect(() => {
    const initData = () => {
      const generatedStudents = generateStudents(250);
      const generatedAlerts = generateAlerts(generatedStudents);
      setStudents(generatedStudents);
      setAlerts(generatedAlerts);
      setSystemStatus(prev => ({
        ...prev,
        predictionsToday: generatedStudents.length,
        lastSync: new Date()
      }));
      setIsLoading(false);
    };

    initData();
  }, []);

  // Simulate real-time updates
  useEffect(() => {
    if (isLoading) return;

    const interval = setInterval(() => {
      // Randomly update a student's data to simulate real-time changes
      setStudents(prevStudents => {
        const updatedStudents = [...prevStudents];
        const randomIndex = Math.floor(Math.random() * updatedStudents.length);
        const student = updatedStudents[randomIndex];
        
        // Small random changes to simulate real-time updates
        const attendanceChange = (Math.random() - 0.5) * 2;
        const newAttendance = Math.max(0, Math.min(100, student.attendance + attendanceChange));
        
        // Recalculate risk score
        const riskChange = (Math.random() - 0.5) * 3;
        const newRiskScore = Math.max(0, Math.min(100, student.riskScore + riskChange));
        const newRiskCategory = newRiskScore <= 40 ? 'low' : newRiskScore <= 70 ? 'medium' : 'high';
        
        // Check if risk category changed to high
        if (newRiskCategory === 'high' && student.riskCategory !== 'high') {
          const newAlert: Alert = {
            id: `ALT${Date.now()}`,
            studentId: student.id,
            studentName: student.name,
            type: 'high_risk',
            message: `${student.name} moved to HIGH RISK with score ${Math.round(newRiskScore)}`,
            timestamp: new Date(),
            read: false
          };
          setAlerts(prev => [newAlert, ...prev]);
        }
        
        updatedStudents[randomIndex] = {
          ...student,
          attendance: Math.round(newAttendance),
          riskScore: Math.round(newRiskScore),
          riskCategory: newRiskCategory,
          lastUpdated: new Date()
        };
        
        return updatedStudents;
      });

      setSystemStatus(prev => ({
        ...prev,
        lastSync: new Date()
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, [isLoading]);

  const riskMetrics: RiskMetrics = useMemo(() => {
    const totalStudents = students.length;
    const lowRisk = students.filter(s => s.riskCategory === 'low').length;
    const mediumRisk = students.filter(s => s.riskCategory === 'medium').length;
    const highRisk = students.filter(s => s.riskCategory === 'high').length;
    
    return {
      totalStudents,
      lowRisk,
      mediumRisk,
      highRisk,
      atRiskPercentage: totalStudents > 0 ? Math.round(((mediumRisk + highRisk) / totalStudents) * 100) : 0,
      averageAttendance: totalStudents > 0 ? Math.round(students.reduce((acc, s) => acc + s.attendance, 0) / totalStudents) : 0,
      averageGrade: totalStudents > 0 ? Math.round(students.reduce((acc, s) => acc + s.averageGrade, 0) / totalStudents) : 0
    };
  }, [students]);

  const filteredStudents = useMemo(() => {
    return students.filter(student => {
      const matchesSearch = student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          student.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRisk = riskFilter === 'all' || student.riskCategory === riskFilter;
      return matchesSearch && matchesRisk;
    });
  }, [students, searchQuery, riskFilter]);

  const unreadAlertsCount = useMemo(() => {
    return alerts.filter(a => !a.read).length;
  }, [alerts]);

  const markAlertAsRead = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, read: true } : alert
    ));
  }, []);

  const markAllAlertsAsRead = useCallback(() => {
    setAlerts(prev => prev.map(alert => ({ ...alert, read: true })));
  }, []);

  const refreshData = useCallback(() => {
    setIsLoading(true);
    setTimeout(() => {
      const generatedStudents = generateStudents(250);
      const generatedAlerts = generateAlerts(generatedStudents);
      setStudents(generatedStudents);
      setAlerts(generatedAlerts);
      setSystemStatus(prev => ({
        ...prev,
        lastSync: new Date(),
        predictionsToday: generatedStudents.length
      }));
      setIsLoading(false);
    }, 1000);
  }, []);

  const exportData = useCallback(() => {
    const dataStr = JSON.stringify(students, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `student-risk-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [students]);

  const getStudentById = useCallback((id: string) => {
    return students.find(s => s.id === id) || null;
  }, [students]);

  const getRecommendationsForStudent = useCallback((student: Student) => {
    if (student.riskCategory === 'low') {
      return ['Continue Engagement'];
    } else if (student.riskCategory === 'medium') {
      return ['Monitor Closely'];
    } else {
      return ['Immediate Counseling', 'Parent Notification', 'Mentorship Plan', 'Attendance Recovery'];
    }
  }, []);

  const onSelectStudent = useCallback((student: Student) => {
    setSelectedStudent(student);
  }, []);

  return {
    students,
    filteredStudents,
    alerts,
    selectedStudent,
    setSelectedStudent,
    searchQuery,
    setSearchQuery,
    riskFilter,
    setRiskFilter,
    riskMetrics,
    systemStatus,
    isLoading,
    unreadAlertsCount,
    markAlertAsRead,
    markAllAlertsAsRead,
    refreshData,
    exportData,
    getStudentById,
    getRecommendationsForStudent,
    onSelectStudent
  };
}
