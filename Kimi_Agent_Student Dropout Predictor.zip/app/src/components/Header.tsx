import { Bell, RefreshCw, Download, Menu, X, Settings, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from '@/lib/utils';
import type { Alert, SystemStatus } from '@/types';

interface HeaderProps {
  unreadAlertsCount: number;
  alerts: Alert[];
  systemStatus: SystemStatus;
  onMarkAlertAsRead: (alertId: string) => void;
  onMarkAllAlertsAsRead: () => void;
  onRefresh: () => void;
  onExport: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
}

export function Header({
  unreadAlertsCount,
  alerts,
  systemStatus,
  onMarkAlertAsRead,
  onMarkAllAlertsAsRead,
  onRefresh,
  onExport,
  isMobileMenuOpen,
  setIsMobileMenuOpen
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="flex h-16 items-center justify-between px-4 lg:px-6">
        {/* Left side */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
          
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 shadow-lg shadow-blue-600/20">
              <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-slate-900">EduGuard AI</h1>
              <p className="text-xs text-slate-500">Dropout Prediction System</p>
            </div>
          </div>
        </div>

        {/* Center - System Status */}
        <div className="hidden md:flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className={`h-2 w-2 rounded-full ${systemStatus.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
            <span className="text-sm text-slate-600">System Online</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span>Model: <span className="font-medium text-slate-700">{systemStatus.modelVersion}</span></span>
            <span className="text-slate-300">|</span>
            <span>Accuracy: <span className="font-medium text-emerald-600">{systemStatus.accuracy}%</span></span>
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="hidden sm:flex items-center gap-2"
            onClick={onRefresh}
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className="hidden sm:flex items-center gap-2"
            onClick={onExport}
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>

          {/* Alerts */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5 text-slate-600" />
                {unreadAlertsCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                  >
                    {unreadAlertsCount}
                  </Badge>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent className="w-full sm:max-w-md">
              <SheetHeader>
                <SheetTitle className="flex items-center justify-between">
                  <span>Alerts & Notifications</span>
                  {unreadAlertsCount > 0 && (
                    <Button variant="ghost" size="sm" onClick={onMarkAllAlertsAsRead}>
                      Mark all read
                    </Button>
                  )}
                </SheetTitle>
              </SheetHeader>
              <ScrollArea className="h-[calc(100vh-8rem)] mt-4">
                <div className="space-y-3">
                  {alerts.length === 0 ? (
                    <div className="text-center py-8 text-slate-500">
                      <Bell className="h-12 w-12 mx-auto mb-3 opacity-30" />
                      <p>No alerts at this time</p>
                    </div>
                  ) : (
                    alerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                          alert.read 
                            ? 'bg-slate-50 border-slate-200' 
                            : 'bg-white border-l-4 border-l-red-500 border-slate-200 shadow-sm'
                        }`}
                        onClick={() => onMarkAlertAsRead(alert.id)}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              {!alert.read && (
                                <div className="h-2 w-2 rounded-full bg-red-500" />
                              )}
                              <span className={`text-sm font-medium ${
                                alert.type === 'high_risk' ? 'text-red-600' : 'text-amber-600'
                              }`}>
                                {alert.type === 'high_risk' ? 'High Risk Alert' : 'Medium Risk Alert'}
                              </span>
                            </div>
                            <p className="text-sm text-slate-700">{alert.message}</p>
                            <p className="text-xs text-slate-400 mt-2">
                              {formatDistanceToNow(alert.timestamp)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </SheetContent>
          </Sheet>

          <Button variant="ghost" size="icon" className="hidden sm:flex">
            <Settings className="h-5 w-5 text-slate-600" />
          </Button>

          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
            <User className="h-4 w-4 text-white" />
          </div>
        </div>
      </div>
    </header>
  );
}
