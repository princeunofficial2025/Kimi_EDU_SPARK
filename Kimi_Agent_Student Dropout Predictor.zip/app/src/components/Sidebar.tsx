import { 
  LayoutDashboard, 
  Users, 
  BarChart3, 
  Bell, 
  MessageSquare, 
  Cloud, 
  Settings,
  GraduationCap,
  Globe
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'students', label: 'Students', icon: Users },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'counselor', label: 'AI Counselor', icon: MessageSquare },
  { id: 'architecture', label: 'Architecture', icon: Cloud },
  { id: 'deployment', label: 'Cloud Ready', icon: Settings },
  { id: 'impact', label: 'Global Impact', icon: Globe },
];

export function Sidebar({ activeTab, setActiveTab, isOpen, setIsOpen }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-16 z-30 h-[calc(100vh-4rem)] w-64 bg-white border-r transition-transform duration-300 ease-in-out lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* School Info */}
          <div className="p-4 border-b">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-slate-100 flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-slate-600" />
              </div>
              <div>
                <p className="font-semibold text-slate-900 text-sm">Lincoln High School</p>
                <p className="text-xs text-slate-500">District #4521</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                    isActive 
                      ? "bg-blue-50 text-blue-600 shadow-sm" 
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  )}
                >
                  <Icon className={cn(
                    "h-5 w-5 transition-colors",
                    isActive ? "text-blue-600" : "text-slate-400"
                  )} />
                  <span>{item.label}</span>
                  {item.id === 'alerts' && (
                    <span className="ml-auto bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                      3
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Bottom Stats */}
          <div className="p-4 border-t bg-slate-50">
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Students</span>
                <span className="font-semibold text-slate-900">250</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">At Risk</span>
                <span className="font-semibold text-red-600">42</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Model Accuracy</span>
                <span className="font-semibold text-emerald-600">94.7%</span>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
