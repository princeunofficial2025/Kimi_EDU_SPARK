import type { Student, Alert, Intervention, ChartData, TrendData } from '@/types';

const firstNames = [
  'Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'Ethan', 'Sophia', 'Mason',
  'Isabella', 'William', 'Mia', 'James', 'Charlotte', 'Benjamin', 'Amelia',
  'Lucas', 'Harper', 'Henry', 'Evelyn', 'Alexander', 'Abigail', 'Michael',
  'Emily', 'Daniel', 'Elizabeth', 'Matthew', 'Sofia', 'Jackson', 'Avery',
  'Sebastian', 'Ella', 'Aiden', 'Madison', 'David', 'Scarlett', 'Joseph',
  'Victoria', 'Samuel', 'Chloe', 'Gabriel', 'Grace', 'Carter', 'Zoey',
  'Owen', 'Nora', 'Dylan', 'Lily', 'Luke', 'Hannah', 'Anthony'
];

const lastNames = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis',
  'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson',
  'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin', 'Lee', 'Perez', 'Thompson',
  'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
  'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen',
  'Hill', 'Flores', 'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera',
  'Campbell', 'Mitchell', 'Carter', 'Roberts'
];

const sections = ['A', 'B', 'C', 'D', 'E'];

function generateRandomName(): string {
  const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
  return `${firstName} ${lastName}`;
}

function generateEmail(name: string): string {
  const normalized = name.toLowerCase().replace(' ', '.');
  return `${normalized}@school.edu`;
}

function calculateRiskScore(student: Partial<Student>): number {
  let score = 0;
  
  // Attendance weight: 30%
  const attendanceRisk = Math.max(0, (100 - (student.attendance || 0)) * 0.3);
  
  // Assignment completion weight: 20%
  const assignmentRisk = Math.max(0, (100 - (student.assignmentCompletion || 0)) * 0.2);
  
  // Grade weight: 25%
  const gradeRisk = Math.max(0, (100 - (student.averageGrade || 0)) * 0.25);
  
  // Absence streak weight: 15%
  const absenceRisk = Math.min(100, (student.absenceStreak || 0) * 10) * 0.15;
  
  // Engagement weight: 10%
  const engagementRisk = Math.max(0, (100 - (student.engagementScore || 50)) * 0.1);
  
  score = attendanceRisk + assignmentRisk + gradeRisk + absenceRisk + engagementRisk;
  
  // Add some randomness for realistic variation
  const randomFactor = (Math.random() - 0.5) * 10;
  score = Math.max(0, Math.min(100, score + randomFactor));
  
  return Math.round(score);
}

function determineRiskCategory(score: number): 'low' | 'medium' | 'high' {
  if (score <= 40) return 'low';
  if (score <= 70) return 'medium';
  return 'high';
}

function determineGradeTrend(attendance: number, grade: number, engagement: number): 'improving' | 'stable' | 'declining' {
  const trendScore = attendance * 0.3 + grade * 0.4 + engagement * 0.3;
  if (trendScore > 75) return 'improving';
  if (trendScore > 50) return 'stable';
  return 'declining';
}

export function generateStudents(count: number = 200): Student[] {
  const students: Student[] = [];
  
  for (let i = 0; i < count; i++) {
    const name = generateRandomName();
    const attendance = Math.round(Math.random() * 40 + 60); // 60-100%
    const assignmentCompletion = Math.round(Math.random() * 50 + 50); // 50-100%
    const averageGrade = Math.round(Math.random() * 50 + 50); // 50-100%
    const behaviorScore = Math.round(Math.random() * 40 + 60); // 60-100%
    const absenceStreak = Math.floor(Math.random() * 8); // 0-7 days
    const engagementScore = Math.round(Math.random() * 50 + 50); // 50-100%
    
    const partialStudent: Partial<Student> = {
      attendance,
      assignmentCompletion,
      averageGrade,
      behaviorScore,
      absenceStreak,
      engagementScore
    };
    
    const riskScore = calculateRiskScore(partialStudent);
    const riskCategory = determineRiskCategory(riskScore);
    const recentGradeTrend = determineGradeTrend(attendance, averageGrade, engagementScore);
    
    const student: Student = {
      id: `STU${String(i + 1).padStart(4, '0')}`,
      name,
      email: generateEmail(name),
      grade: Math.floor(Math.random() * 4) + 9, // 9-12
      section: sections[Math.floor(Math.random() * sections.length)],
      attendance,
      assignmentCompletion,
      averageGrade,
      behaviorScore,
      absenceStreak,
      engagementScore,
      recentGradeTrend,
      riskScore,
      riskCategory,
      lastUpdated: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
      interventions: []
    };
    
    students.push(student);
  }
  
  return students;
}

export function generateAlerts(students: Student[]): Alert[] {
  const highRiskStudents = students.filter(s => s.riskCategory === 'high');
  const alerts: Alert[] = [];
  
  highRiskStudents.slice(0, 15).forEach((student, index) => {
    alerts.push({
      id: `ALT${String(index + 1).padStart(4, '0')}`,
      studentId: student.id,
      studentName: student.name,
      type: 'high_risk',
      message: `${student.name} is at high risk of dropout with a risk score of ${student.riskScore}`,
      timestamp: new Date(Date.now() - Math.random() * 3 * 24 * 60 * 60 * 1000),
      read: false
    });
  });
  
  // Add some medium risk alerts
  const mediumRiskStudents = students.filter(s => s.riskCategory === 'medium');
  mediumRiskStudents.slice(0, 10).forEach((student, index) => {
    alerts.push({
      id: `ALT${String(alerts.length + index + 1).padStart(4, '0')}`,
      studentId: student.id,
      studentName: student.name,
      type: 'medium_risk',
      message: `${student.name} shows declining performance. Risk score: ${student.riskScore}`,
      timestamp: new Date(Date.now() - Math.random() * 5 * 24 * 60 * 60 * 1000),
      read: Math.random() > 0.5
    });
  });
  
  return alerts.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
}

export const interventions: Intervention[] = [
  {
    id: '1',
    title: 'Continue Engagement',
    description: 'Student is performing well. Maintain current support levels and encourage continued participation.',
    category: 'low',
    icon: 'ThumbsUp',
    actions: ['Send positive reinforcement', 'Encourage peer mentoring', 'Recognize achievements']
  },
  {
    id: '2',
    title: 'Monitor Closely',
    description: 'Student showing early warning signs. Increase observation and provide academic support.',
    category: 'medium',
    icon: 'Eye',
    actions: ['Weekly check-ins', 'Academic tutoring', 'Study skills workshop']
  },
  {
    id: '3',
    title: 'Immediate Counseling',
    description: 'High-risk student requires urgent intervention. Schedule counseling session within 48 hours.',
    category: 'high',
    icon: 'AlertTriangle',
    actions: ['Schedule counselor meeting', 'Contact parents', 'Develop action plan']
  },
  {
    id: '4',
    title: 'Parent Notification',
    description: 'Engage parents/guardians in the support process for comprehensive care.',
    category: 'high',
    icon: 'Phone',
    actions: ['Schedule parent conference', 'Share progress reports', 'Home support strategies']
  },
  {
    id: '5',
    title: 'Mentorship Plan',
    description: 'Assign a mentor to provide one-on-one guidance and support.',
    category: 'high',
    icon: 'Users',
    actions: ['Match with mentor', 'Set weekly meetings', 'Track progress']
  },
  {
    id: '6',
    title: 'Attendance Recovery',
    description: 'Develop a structured plan to improve attendance and catch up on missed work.',
    category: 'high',
    icon: 'Calendar',
    actions: ['Identify barriers', 'Create schedule', 'Provide transportation support']
  }
];

export function getRiskDistribution(students: Student[]): ChartData[] {
  const low = students.filter(s => s.riskCategory === 'low').length;
  const medium = students.filter(s => s.riskCategory === 'medium').length;
  const high = students.filter(s => s.riskCategory === 'high').length;
  
  return [
    { name: 'Low Risk', value: low, color: '#10b981' },
    { name: 'Medium Risk', value: medium, color: '#f59e0b' },
    { name: 'High Risk', value: high, color: '#ef4444' }
  ];
}

export function getAttendanceTrend(): TrendData[] {
  const data: TrendData[] = [];
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  
  days.forEach((day) => {
    data.push({
      date: day,
      attendance: Math.round(85 + Math.random() * 10),
      grade: Math.round(75 + Math.random() * 15),
      riskScore: Math.round(30 + Math.random() * 20)
    });
  });
  
  return data;
}

export function getGradeDistribution(students: Student[]): ChartData[] {
  const ranges = [
    { name: '90-100', min: 90, max: 100, color: '#10b981' },
    { name: '80-89', min: 80, max: 89, color: '#84cc16' },
    { name: '70-79', min: 70, max: 79, color: '#eab308' },
    { name: '60-69', min: 60, max: 69, color: '#f97316' },
    { name: 'Below 60', min: 0, max: 59, color: '#ef4444' }
  ];
  
  return ranges.map(range => ({
    name: range.name,
    value: students.filter(s => s.averageGrade >= range.min && s.averageGrade <= range.max).length,
    color: range.color
  }));
}

export function getHeatmapData() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  const hours = ['8AM', '10AM', '12PM', '2PM', '4PM'];
  const data: { day: string; hour: string; value: number }[] = [];
  
  days.forEach(day => {
    hours.forEach(hour => {
      data.push({
        day,
        hour,
        value: Math.round(Math.random() * 100)
      });
    });
  });
  
  return data;
}
