import { useState } from 'react';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { RiskOverviewPanel } from '@/sections/RiskOverviewPanel';
import { ChartsSection } from '@/sections/ChartsSection';
import { StudentTable } from '@/sections/StudentTable';
import { AlertsFeed } from '@/sections/AlertsFeed';
import { RecommendationsEngine } from '@/sections/RecommendationsEngine';
import { AICounselor } from '@/sections/AICounselor';
import { ArchitectureVisualization } from '@/sections/ArchitectureVisualization';
import { CloudReadyPanel } from '@/sections/CloudReadyPanel';
import { GlobalImpact } from '@/sections/GlobalImpact';
import { SettingsPanel } from '@/sections/SettingsPanel';
import { useStudents } from '@/hooks/useStudents';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const {
    students,
    filteredStudents,
    alerts,
    searchQuery,
    setSearchQuery,
    riskFilter,
    setRiskFilter,
    riskMetrics,
    systemStatus,
    isLoading,
    unreadAlertsCount,
    markAlertAsRead,
    markAllAlertsAsRead,
    refreshData,
    exportData,
    onSelectStudent
  } = useStudents();

  const handleRefresh = () => {
    refreshData();
    toast.success('Data refreshed successfully');
  };

  const handleExport = () => {
    exportData();
    toast.success('Report exported successfully');
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-96">
          <div className="flex flex-col items-center gap-4">
            <div className="h-12 w-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            <p className="text-slate-500">Loading student data...</p>
          </div>
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <RiskOverviewPanel 
              riskMetrics={riskMetrics} 
              systemStatus={systemStatus} 
            />
            <ChartsSection students={students} />
            <StudentTable 
              students={filteredStudents}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              riskFilter={riskFilter}
              setRiskFilter={setRiskFilter}
              onSelectStudent={onSelectStudent}
            />
          </div>
        );
      
      case 'students':
        return (
          <div className="space-y-6">
            <RiskOverviewPanel 
              riskMetrics={riskMetrics} 
              systemStatus={systemStatus} 
            />
            <StudentTable 
              students={filteredStudents}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              riskFilter={riskFilter}
              setRiskFilter={setRiskFilter}
              onSelectStudent={onSelectStudent}
            />
          </div>
        );
      
      case 'analytics':
        return (
          <div className="space-y-6">
            <ChartsSection students={students} />
            <RecommendationsEngine />
          </div>
        );
      
      case 'alerts':
        return (
          <AlertsFeed 
            alerts={alerts}
            students={students}
            onMarkAsRead={markAlertAsRead}
            onSelectStudent={onSelectStudent}
          />
        );
      
      case 'counselor':
        return <AICounselor />;
      
      case 'architecture':
        return <ArchitectureVisualization />;
      
      case 'deployment':
        return <CloudReadyPanel />;
      
      case 'impact':
        return <GlobalImpact />;
      
      case 'settings':
        return <SettingsPanel />;
      
      default:
        return (
          <div className="space-y-6">
            <RiskOverviewPanel 
              riskMetrics={riskMetrics} 
              systemStatus={systemStatus} 
            />
            <ChartsSection students={students} />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header
        unreadAlertsCount={unreadAlertsCount}
        alerts={alerts}
        systemStatus={systemStatus}
        onMarkAlertAsRead={markAlertAsRead}
        onMarkAllAlertsAsRead={markAllAlertsAsRead}
        onRefresh={handleRefresh}
        onExport={handleExport}
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
      />
      
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpen={isMobileMenuOpen}
        setIsOpen={setIsMobileMenuOpen}
      />
      
      <main className="lg:ml-64 pt-16 min-h-screen">
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
      
      <Toaster position="top-right" />
    </div>
  );
}

export default App;
