export interface Student {
  id: string;
  name: string;
  email: string;
  grade: number;
  section: string;
  attendance: number;
  assignmentCompletion: number;
  averageGrade: number;
  behaviorScore: number;
  absenceStreak: number;
  engagementScore: number;
  recentGradeTrend: 'improving' | 'stable' | 'declining';
  riskScore: number;
  riskCategory: 'low' | 'medium' | 'high';
  lastUpdated: Date;
  interventions: string[];
}

export interface RiskMetrics {
  totalStudents: number;
  lowRisk: number;
  mediumRisk: number;
  highRisk: number;
  atRiskPercentage: number;
  averageAttendance: number;
  averageGrade: number;
}

export interface Alert {
  id: string;
  studentId: string;
  studentName: string;
  type: 'high_risk' | 'medium_risk' | 'attendance_drop' | 'grade_drop';
  message: string;
  timestamp: Date;
  read: boolean;
}

export interface Intervention {
  id: string;
  title: string;
  description: string;
  category: 'low' | 'medium' | 'high';
  icon: string;
  actions: string[];
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
}

export interface TrendData {
  date: string;
  attendance: number;
  grade: number;
  riskScore: number;
}

export interface HeatmapData {
  day: string;
  hour: string;
  value: number;
}

export interface SystemStatus {
  isOnline: boolean;
  lastSync: Date;
  modelVersion: string;
  accuracy: number;
  predictionsToday: number;
}
