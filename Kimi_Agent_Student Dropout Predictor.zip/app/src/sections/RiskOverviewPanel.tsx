import { Users, TrendingUp, AlertTriangle, Activity, Clock } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { RiskMetrics, SystemStatus } from '@/types';

interface RiskOverviewPanelProps {
  riskMetrics: RiskMetrics;
  systemStatus: SystemStatus;
}

export function RiskOverviewPanel({ riskMetrics, systemStatus }: RiskOverviewPanelProps) {
  const cards = [
    {
      title: 'Total Students',
      value: riskMetrics.totalStudents,
      subtitle: 'Active monitoring',
      icon: Users,
      color: 'blue',
      trend: '+5 this week'
    },
    {
      title: 'Low Risk',
      value: riskMetrics.lowRisk,
      subtitle: `${Math.round((riskMetrics.lowRisk / riskMetrics.totalStudents) * 100)}% of students`,
      icon: TrendingUp,
      color: 'emerald',
      trend: 'Stable'
    },
    {
      title: 'Medium Risk',
      value: riskMetrics.mediumRisk,
      subtitle: 'Needs attention',
      icon: Activity,
      color: 'amber',
      trend: '+3 this week'
    },
    {
      title: 'High Risk',
      value: riskMetrics.highRisk,
      subtitle: 'Urgent intervention',
      icon: AlertTriangle,
      color: 'red',
      trend: 'Critical'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string; icon: string }> = {
      blue: {
        bg: 'bg-blue-50',
        text: 'text-blue-900',
        border: 'border-blue-200',
        icon: 'text-blue-600'
      },
      emerald: {
        bg: 'bg-emerald-50',
        text: 'text-emerald-900',
        border: 'border-emerald-200',
        icon: 'text-emerald-600'
      },
      amber: {
        bg: 'bg-amber-50',
        text: 'text-amber-900',
        border: 'border-amber-200',
        icon: 'text-amber-600'
      },
      red: {
        bg: 'bg-red-50',
        text: 'text-red-900',
        border: 'border-red-200',
        icon: 'text-red-600'
      }
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="space-y-4">
      {/* Header with live indicator */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Risk Overview</h2>
          <p className="text-sm text-slate-500">Real-time student risk assessment</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 rounded-full border border-emerald-200">
            <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-medium text-emerald-700">Live</span>
          </div>
          <div className="flex items-center gap-1.5 text-sm text-slate-500">
            <Clock className="h-4 w-4" />
            <span>Updated {systemStatus.lastSync.toLocaleTimeString()}</span>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, index) => {
          const colors = getColorClasses(card.color);
          const Icon = card.icon;
          
          return (
            <Card 
              key={index} 
              className={`overflow-hidden border ${colors.border} hover:shadow-lg transition-shadow duration-300`}
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className={`p-3 rounded-xl ${colors.bg}`}>
                    <Icon className={`h-6 w-6 ${colors.icon}`} />
                  </div>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${
                      card.trend === 'Critical' 
                        ? 'bg-red-50 text-red-700 border-red-200' 
                        : card.trend === 'Stable'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    {card.trend}
                  </Badge>
                </div>
                <div className="mt-4">
                  <p className="text-3xl font-bold text-slate-900">{card.value}</p>
                  <p className={`text-sm font-medium ${colors.text} mt-1`}>{card.title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{card.subtitle}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Summary Bar */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-4 text-white">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-white/10 rounded-lg">
              <Activity className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-slate-300">At-Risk Students</p>
              <p className="text-xl font-bold">{riskMetrics.mediumRisk + riskMetrics.highRisk} 
                <span className="text-sm font-normal text-slate-400 ml-1">
                  ({riskMetrics.atRiskPercentage}%)
                </span>
              </p>
            </div>
          </div>
          <div className="h-10 w-px bg-white/20 hidden sm:block" />
          <div className="flex items-center gap-4">
            <div>
              <p className="text-sm text-slate-300">Avg Attendance</p>
              <p className="text-xl font-bold">{riskMetrics.averageAttendance}%</p>
            </div>
          </div>
          <div className="h-10 w-px bg-white/20 hidden sm:block" />
          <div className="flex items-center gap-4">
            <div>
              <p className="text-sm text-slate-300">Avg Grade</p>
              <p className="text-xl font-bold">{riskMetrics.averageGrade}%</p>
            </div>
          </div>
          <div className="h-10 w-px bg-white/20 hidden sm:block" />
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-sm text-slate-300">AI Model Active</span>
          </div>
        </div>
      </div>
    </div>
  );
}
