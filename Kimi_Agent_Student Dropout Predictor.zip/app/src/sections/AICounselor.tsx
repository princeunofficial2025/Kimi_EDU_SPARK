import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Lightbulb, BookOpen, Heart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

const initialMessages: Message[] = [
  {
    id: '1',
    role: 'assistant',
    content: 'Hello! I am EduGuard AI Counselor. I can help you with student intervention strategies, analyze risk patterns, and provide personalized recommendations. How can I assist you today?',
    timestamp: new Date(),
    suggestions: [
      'Show me high-risk students',
      'What interventions work best?',
      'Analyze attendance patterns'
    ]
  }
];

const sampleResponses: Record<string, string> = {
  'high-risk': `Based on current data, we have 42 high-risk students. The top factors contributing to their risk scores are:

1. Low attendance (below 70%)
2. Declining grade trends
3. Multiple absence streaks

I recommend immediate counseling for the top 10 students with scores above 85. Would you like me to generate individual intervention plans?`,

  'interventions': `Here are the most effective intervention strategies based on our ML model analysis:

**For High Risk (Score 71-100):**
- Immediate 1-on-1 counseling
- Parent/guardian notification within 24hrs
- Daily check-ins for 2 weeks
- Academic support tutoring

**For Medium Risk (Score 41-70):**
- Weekly progress monitoring
- Study skills workshop
- Peer mentoring program
- Teacher check-ins

**Success Rate:** 78% of students who received timely interventions showed improvement within 4 weeks.`,

  'attendance': `Attendance pattern analysis for this semester:

**Key Findings:**
- Monday absences are 34% higher than other days
- Students with >5 consecutive absences have 89% dropout risk
- Transportation issues affect 23% of at-risk students

**Recommendations:**
- Implement attendance incentive program
- Provide transportation support
- Flexible scheduling for working students
- Early intervention at 3 consecutive absences`,

  'default': `I understand your concern. Let me analyze the student data and provide personalized recommendations.

Based on the risk assessment model, I suggest:

1. Review individual student profiles for detailed insights
2. Consider the student's complete context (home, social, academic)
3. Collaborate with teachers, counselors, and parents
4. Set measurable goals and track progress weekly

Would you like me to dive deeper into any specific aspect?`
};

export function AICounselor() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const generateResponse = (userMessage: string): string => {
    const lowerMsg = userMessage.toLowerCase();
    if (lowerMsg.includes('high') || lowerMsg.includes('risk')) {
      return sampleResponses['high-risk'];
    }
    if (lowerMsg.includes('intervention') || lowerMsg.includes('strategy')) {
      return sampleResponses['interventions'];
    }
    if (lowerMsg.includes('attendance') || lowerMsg.includes('absent')) {
      return sampleResponses['attendance'];
    }
    return sampleResponses['default'];
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const response = generateResponse(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
        suggestions: ['Tell me more', 'Generate report', 'Schedule meeting']
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSuggestion = (suggestion: string) => {
    setInput(suggestion);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">AI Counseling Assistant</h2>
          <p className="text-sm text-slate-500">Get intelligent insights and intervention recommendations</p>
        </div>
        <Badge className="bg-purple-100 text-purple-700 border-purple-200">
          <Sparkles className="h-3 w-3 mr-1" />
          Powered by AI
        </Badge>
      </div>

      <Card className="border-slate-200">
        <CardHeader className="pb-3 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg font-semibold text-slate-900">EduGuard Counselor</CardTitle>
              <p className="text-xs text-slate-500">ML-powered student support assistant</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[400px] p-4" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.role === 'user' 
                      ? 'bg-slate-200' 
                      : 'bg-gradient-to-br from-blue-600 to-indigo-600'
                  }`}>
                    {message.role === 'user' ? (
                      <User className="h-4 w-4 text-slate-600" />
                    ) : (
                      <Bot className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <div className={`max-w-[80%] space-y-2 ${message.role === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`p-3 rounded-lg text-sm ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 text-slate-800'
                    }`}>
                      <div className="whitespace-pre-line">{message.content}</div>
                    </div>
                    {message.suggestions && message.suggestions.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {message.suggestions.map((suggestion, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSuggestion(suggestion)}
                            className="text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-full hover:bg-slate-50 hover:border-slate-300 transition-colors text-slate-600"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                  <div className="bg-slate-100 p-3 rounded-lg">
                    <div className="flex gap-1">
                      <div className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <div className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <div className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          
          {/* Input Area */}
          <div className="p-4 border-t bg-slate-50">
            <div className="flex gap-2">
              <Input
                placeholder="Ask about student interventions, risk analysis, or recommendations..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                className="flex-1"
              />
              <Button onClick={handleSend} disabled={!input.trim() || isTyping}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              <button
                onClick={() => handleSuggestion('Show high-risk students')}
                className="text-xs flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-200 rounded-full hover:bg-slate-50 transition-colors text-slate-600"
              >
                <Heart className="h-3 w-3 text-red-500" />
                High-risk students
              </button>
              <button
                onClick={() => handleSuggestion('Best interventions?')}
                className="text-xs flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-200 rounded-full hover:bg-slate-50 transition-colors text-slate-600"
              >
                <Lightbulb className="h-3 w-3 text-amber-500" />
                Best interventions
              </button>
              <button
                onClick={() => handleSuggestion('Analyze attendance')}
                className="text-xs flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-200 rounded-full hover:bg-slate-50 transition-colors text-slate-600"
              >
                <BookOpen className="h-3 w-3 text-blue-500" />
                Attendance analysis
              </button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Tips */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-5 w-5 text-blue-600" />
              <h4 className="font-semibold text-blue-900">Pro Tip</h4>
            </div>
            <p className="text-sm text-blue-700">
              Early intervention within 2 weeks of risk detection increases success rates by 65%.
            </p>
          </CardContent>
        </Card>
        <Card className="border-emerald-200 bg-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="h-5 w-5 text-emerald-600" />
              <h4 className="font-semibold text-emerald-900">Success Story</h4>
            </div>
            <p className="text-sm text-emerald-700">
              78% of students with timely interventions showed improvement within 4 weeks.
            </p>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="h-5 w-5 text-amber-600" />
              <h4 className="font-semibold text-amber-900">Did You Know?</h4>
            </div>
            <p className="text-sm text-amber-700">
              Monday absences are 34% higher than other days - consider Monday check-ins.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
