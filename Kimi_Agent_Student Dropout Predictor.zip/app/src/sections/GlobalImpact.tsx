import { 
  Globe, 
  GraduationCap, 
  TrendingUp, 
  Users, 
  Heart,
  Target,
  Award,
  BookOpen,
  ArrowUpRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const sdgGoals = [
  {
    number: '4',
    title: 'Quality Education',
    description: 'Ensure inclusive and equitable quality education for all',
    color: 'bg-red-500',
    icon: BookOpen
  },
  {
    number: '10',
    title: 'Reduced Inequalities',
    description: 'Reduce inequality within and among countries',
    color: 'bg-pink-500',
    icon: Users
  },
  {
    number: '17',
    title: 'Partnerships',
    description: 'Strengthen global partnerships for sustainable development',
    color: 'bg-blue-500',
    icon: Globe
  }
];

const globalStats = [
  {
    region: 'Sub-Saharan Africa',
    dropoutRate: 32,
    studentsAtRisk: '45M',
    color: 'red'
  },
  {
    region: 'South Asia',
    dropoutRate: 28,
    studentsAtRisk: '38M',
    color: 'amber'
  },
  {
    region: 'Latin America',
    dropoutRate: 18,
    studentsAtRisk: '12M',
    color: 'yellow'
  },
  {
    region: 'Middle East & North Africa',
    dropoutRate: 22,
    studentsAtRisk: '8M',
    color: 'orange'
  },
  {
    region: 'East Asia & Pacific',
    dropoutRate: 8,
    studentsAtRisk: '15M',
    color: 'green'
  },
  {
    region: 'Europe & Central Asia',
    dropoutRate: 6,
    studentsAtRisk: '4M',
    color: 'emerald'
  }
];

const impactMetrics = [
  {
    title: 'Students Protected',
    value: '2.5M+',
    change: '+34%',
    description: 'Active students monitored globally',
    icon: Users,
    color: 'blue'
  },
  {
    title: 'Dropouts Prevented',
    value: '156K',
    change: '+28%',
    description: 'Students retained through early intervention',
    icon: GraduationCap,
    color: 'emerald'
  },
  {
    title: 'Success Rate',
    value: '78%',
    change: '+12%',
    description: 'Intervention success rate',
    icon: Target,
    color: 'purple'
  },
  {
    title: 'Schools Partnered',
    value: '1,200+',
    change: '+45%',
    description: 'Educational institutions using EduGuard',
    icon: Award,
    color: 'amber'
  }
];

const successStories = [
  {
    school: 'Lincoln High School',
    location: 'Chicago, USA',
    result: '45% reduction in dropout rate',
    quote: 'EduGuard helped us identify at-risk students 3 weeks earlier than traditional methods.',
    author: 'Dr. Sarah Johnson, Principal'
  },
  {
    school: 'Sunrise Academy',
    location: 'Mumbai, India',
    result: '200+ students retained',
    quote: 'The AI predictions are incredibly accurate. We can now intervene before its too late.',
    author: 'Raj Patel, School Counselor'
  },
  {
    school: 'Green Valley School',
    location: 'Nairobi, Kenya',
    result: '60% improvement in attendance',
    quote: 'This platform has transformed how we support our students. Truly life-changing.',
    author: 'Grace Ochieng, Head Teacher'
  }
];

export function GlobalImpact() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Global Impact</h2>
          <p className="text-sm text-slate-500">Advancing SDG 4: Quality Education for All</p>
        </div>
        <Badge className="bg-red-100 text-red-700 border-red-200">
          <Heart className="h-3 w-3 mr-1" />
          SDG 4 Aligned
        </Badge>
      </div>

      {/* SDG Goals */}
      <Card className="border-slate-200 overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-red-600 to-pink-600 text-white">
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            UN Sustainable Development Goals
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {sdgGoals.map((goal, index) => (
              <div key={index} className="flex items-start gap-3 p-4 rounded-lg bg-slate-50 border border-slate-200">
                <div className={`${goal.color} text-white w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg flex-shrink-0`}>
                  {goal.number}
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">{goal.title}</h4>
                  <p className="text-sm text-slate-600 mt-1">{goal.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Impact Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {impactMetrics.map((metric, index) => {
          const Icon = metric.icon;
          const colors: Record<string, { bg: string; text: string; border: string }> = {
            blue: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
            emerald: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
            purple: { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200' },
            amber: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' }
          };
          const color = colors[metric.color];

          return (
            <Card key={index} className={`border ${color.border} ${color.bg}`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className={`p-2 bg-white rounded-lg ${color.text}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <Badge variant="outline" className="bg-white text-emerald-600 border-emerald-200">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {metric.change}
                  </Badge>
                </div>
                <div className="mt-3">
                  <p className={`text-2xl font-bold ${color.text}`}>{metric.value}</p>
                  <p className="text-sm font-medium text-slate-900">{metric.title}</p>
                  <p className="text-xs text-slate-500 mt-1">{metric.description}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Global Dropout Statistics */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Globe className="h-5 w-5 text-blue-600" />
            Global Dropout Statistics by Region
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {globalStats.map((stat, index) => {
              const colors: Record<string, { bar: string; text: string }> = {
                red: { bar: 'bg-red-500', text: 'text-red-600' },
                amber: { bar: 'bg-amber-500', text: 'text-amber-600' },
                yellow: { bar: 'bg-yellow-500', text: 'text-yellow-600' },
                orange: { bar: 'bg-orange-500', text: 'text-orange-600' },
                green: { bar: 'bg-green-500', text: 'text-green-600' },
                emerald: { bar: 'bg-emerald-500', text: 'text-emerald-600' }
              };
              const color = colors[stat.color];

              return (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-900">{stat.region}</span>
                      <Badge variant="outline" className="text-xs">
                        {stat.studentsAtRisk} at risk
                      </Badge>
                    </div>
                    <span className={`text-sm font-bold ${color.text}`}>{stat.dropoutRate}%</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${color.bar} rounded-full transition-all duration-500`}
                      style={{ width: `${stat.dropoutRate * 2}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-6 p-4 bg-slate-50 rounded-lg">
            <p className="text-sm text-slate-600">
              <strong className="text-slate-900">Global Challenge:</strong> Over 244 million children and youth worldwide are out of school. 
              Early warning systems like EduGuard can help reduce dropout rates by up to 40% through timely interventions.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Success Stories */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-900">Success Stories</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {successStories.map((story, index) => (
            <Card key={index} className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-semibold text-slate-900">{story.school}</h4>
                    <p className="text-sm text-slate-500">{story.location}</p>
                  </div>
                  <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {story.result}
                  </Badge>
                </div>
                <blockquote className="text-sm text-slate-600 italic mb-3">
                  &ldquo;{story.quote}&rdquo;
                </blockquote>
                <p className="text-xs text-slate-500">— {story.author}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <Card className="border-slate-200 bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold">Join the Movement</h3>
              <p className="text-sm text-emerald-100">
                Partner with us to make quality education accessible to every child worldwide.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" className="bg-white text-emerald-600 hover:bg-emerald-50">
                <Heart className="h-4 w-4 mr-2" />
                Partner With Us
              </Button>
              <Button className="bg-emerald-800 hover:bg-emerald-900 text-white">
                Learn More
                <ArrowUpRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
