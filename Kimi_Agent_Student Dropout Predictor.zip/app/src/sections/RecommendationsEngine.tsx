import { 
  ThumbsUp, 
  Eye, 
  AlertTriangle, 
  Phone, 
  Users, 
  Calendar,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { interventions } from '@/data/mockData';

const iconMap: Record<string, React.ElementType> = {
  ThumbsUp,
  Eye,
  AlertTriangle,
  Phone,
  Users,
  Calendar
};

export function RecommendationsEngine() {
  const lowRiskInterventions = interventions.filter(i => i.category === 'low');
  const mediumRiskInterventions = interventions.filter(i => i.category === 'medium');
  const highRiskInterventions = interventions.filter(i => i.category === 'high');

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'low':
        return {
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
          title: 'text-emerald-900',
          icon: 'text-emerald-600',
          badge: 'bg-emerald-100 text-emerald-700'
        };
      case 'medium':
        return {
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          title: 'text-amber-900',
          icon: 'text-amber-600',
          badge: 'bg-amber-100 text-amber-700'
        };
      case 'high':
        return {
          bg: 'bg-red-50',
          border: 'border-red-200',
          title: 'text-red-900',
          icon: 'text-red-600',
          badge: 'bg-red-100 text-red-700'
        };
      default:
        return {
          bg: 'bg-slate-50',
          border: 'border-slate-200',
          title: 'text-slate-900',
          icon: 'text-slate-600',
          badge: 'bg-slate-100 text-slate-700'
        };
    }
  };

  const InterventionCard = ({ intervention }: { intervention: typeof interventions[0] }) => {
    const colors = getCategoryColor(intervention.category);
    const Icon = iconMap[intervention.icon] || Eye;

    return (
      <Card className={`border ${colors.border} ${colors.bg} hover:shadow-md transition-shadow`}>
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-lg bg-white ${colors.icon}`}>
              <Icon className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h4 className={`font-semibold ${colors.title}`}>{intervention.title}</h4>
                <Badge className={`text-xs ${colors.badge}`}>
                  {intervention.category} risk
                </Badge>
              </div>
              <p className="text-sm text-slate-600 mb-3">{intervention.description}</p>
              <div className="space-y-2">
                <p className="text-xs font-medium text-slate-500">Recommended Actions:</p>
                <div className="flex flex-wrap gap-2">
                  {intervention.actions.map((action, idx) => (
                    <div key={idx} className="flex items-center gap-1 text-xs text-slate-600">
                      <CheckCircle className="h-3 w-3 text-emerald-500" />
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">AI Recommendations Engine</h2>
          <p className="text-sm text-slate-500">Personalized intervention strategies based on risk assessment</p>
        </div>
        <Button variant="outline" className="hidden sm:flex items-center gap-2">
          <CheckCircle className="h-4 w-4" />
          <span>Apply to All</span>
        </Button>
      </div>

      {/* Risk Level Legend */}
      <div className="flex flex-wrap gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-emerald-500" />
          <span className="text-sm text-slate-600">Low Risk (0-40): Encourage engagement</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-amber-500" />
          <span className="text-sm text-slate-600">Medium Risk (41-70): Monitor closely</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-red-500" />
          <span className="text-sm text-slate-600">High Risk (71-100): Immediate action</span>
        </div>
      </div>

      {/* Intervention Categories */}
      <div className="space-y-6">
        {/* High Risk Interventions */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            <h3 className="text-lg font-semibold text-slate-900">High Risk Interventions</h3>
            <Badge variant="destructive" className="ml-2">{highRiskInterventions.length}</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {highRiskInterventions.map((intervention) => (
              <InterventionCard key={intervention.id} intervention={intervention} />
            ))}
          </div>
        </div>

        {/* Medium Risk Interventions */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Eye className="h-5 w-5 text-amber-500" />
            <h3 className="text-lg font-semibold text-slate-900">Medium Risk Interventions</h3>
            <Badge className="ml-2 bg-amber-100 text-amber-700">{mediumRiskInterventions.length}</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mediumRiskInterventions.map((intervention) => (
              <InterventionCard key={intervention.id} intervention={intervention} />
            ))}
          </div>
        </div>

        {/* Low Risk Interventions */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <ThumbsUp className="h-5 w-5 text-emerald-500" />
            <h3 className="text-lg font-semibold text-slate-900">Low Risk Interventions</h3>
            <Badge className="ml-2 bg-emerald-100 text-emerald-700">{lowRiskInterventions.length}</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {lowRiskInterventions.map((intervention) => (
              <InterventionCard key={intervention.id} intervention={intervention} />
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold text-slate-900">Bulk Actions</h3>
              <p className="text-sm text-slate-600">Apply interventions to multiple students at once</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" className="bg-white">
                Notify Counselors
              </Button>
              <Button variant="outline" className="bg-white">
                Send Parent Emails
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Generate Reports
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
