import { Bell, AlertTriangle, Eye, CheckCircle, Clock, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { Alert, Student } from '@/types';
import { formatDistanceToNow } from '@/lib/utils';

interface AlertsFeedProps {
  alerts: Alert[];
  students: Student[];
  onMarkAsRead: (alertId: string) => void;
  onSelectStudent: (student: Student) => void;
}

export function AlertsFeed({ alerts, students, onMarkAsRead, onSelectStudent }: AlertsFeedProps) {
  const highRiskAlerts = alerts.filter(a => a.type === 'high_risk');
  const mediumRiskAlerts = alerts.filter(a => a.type === 'medium_risk');
  const unreadAlerts = alerts.filter(a => !a.read);

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'high_risk':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'medium_risk':
        return <Bell className="h-5 w-5 text-amber-500" />;
      default:
        return <Bell className="h-5 w-5 text-slate-500" />;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'high_risk':
        return 'border-l-red-500 bg-red-50';
      case 'medium_risk':
        return 'border-l-amber-500 bg-amber-50';
      default:
        return 'border-l-slate-500 bg-slate-50';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Recent Alerts</h2>
          <p className="text-sm text-slate-500">Real-time notifications for at-risk students</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="destructive" className="px-2 py-1">
            {unreadAlerts.length} Unread
          </Badge>
          <Select defaultValue="all">
            <SelectTrigger className="w-32">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Alerts</SelectItem>
              <SelectItem value="unread">Unread</SelectItem>
              <SelectItem value="high">High Risk</SelectItem>
              <SelectItem value="medium">Medium Risk</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Alert Summary Cards */}
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 rounded-lg">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-red-700">{highRiskAlerts.length}</p>
                  <p className="text-sm text-red-600">High Risk Alerts</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Bell className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-amber-700">{mediumRiskAlerts.length}</p>
                  <p className="text-sm text-amber-600">Medium Risk Alerts</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-200 bg-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-emerald-700">{alerts.length - unreadAlerts.length}</p>
                  <p className="text-sm text-emerald-600">Resolved Today</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alert Feed */}
      <Card className="border-slate-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold text-slate-900">Alert Timeline</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[400px]">
            <div className="divide-y divide-slate-200">
              {alerts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                  <CheckCircle className="h-12 w-12 mb-3 opacity-30" />
                  <p>No alerts at this time</p>
                  <p className="text-sm">All students are within normal parameters</p>
                </div>
              ) : (
                alerts.map((alert) => {
                  const student = students.find(s => s.id === alert.studentId);
                  return (
                    <div 
                      key={alert.id} 
                      className={`p-4 border-l-4 transition-all hover:bg-slate-50 ${
                        alert.read ? 'border-l-slate-300 bg-white' : getAlertColor(alert.type)
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`p-2 rounded-lg ${
                          alert.type === 'high_risk' ? 'bg-red-100' : 
                          alert.type === 'medium_risk' ? 'bg-amber-100' : 'bg-slate-100'
                        }`}>
                          {getAlertIcon(alert.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="font-medium text-slate-900">
                                {alert.type === 'high_risk' ? 'High Risk Alert' : 'Medium Risk Alert'}
                              </p>
                              <p className="text-sm text-slate-600 mt-1">{alert.message}</p>
                            </div>
                            {!alert.read && (
                              <div className="h-2 w-2 rounded-full bg-red-500 flex-shrink-0" />
                            )}
                          </div>
                          <div className="flex items-center gap-4 mt-3">
                            <div className="flex items-center gap-1 text-xs text-slate-500">
                              <Clock className="h-3 w-3" />
                              <span>{formatDistanceToNow(alert.timestamp)}</span>
                            </div>
                            {student && (
                              <div className="flex items-center gap-2">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-7 text-xs"
                                  onClick={() => onSelectStudent(student)}
                                >
                                  <Eye className="h-3 w-3 mr-1" />
                                  View Profile
                                </Button>
                                {!alert.read && (
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-7 text-xs"
                                    onClick={() => onMarkAsRead(alert.id)}
                                  >
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    Mark Read
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
