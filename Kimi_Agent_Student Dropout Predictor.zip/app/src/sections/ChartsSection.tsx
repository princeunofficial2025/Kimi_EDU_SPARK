import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  BarChart,
  Bar
} from 'recharts';
import type { Student } from '@/types';
import { getRiskDistribution, getAttendanceTrend, getGradeDistribution, getHeatmapData } from '@/data/mockData';

interface ChartsSectionProps {
  students: Student[];
}

export function ChartsSection({ students }: ChartsSectionProps) {
  const riskData = useMemo(() => getRiskDistribution(students), [students]);
  const attendanceData = useMemo(() => getAttendanceTrend(), []);
  const gradeData = useMemo(() => getGradeDistribution(students), [students]);
  const heatmapData = useMemo(() => getHeatmapData(), []);

  const COLORS = ['#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Visual Insights</h2>
          <p className="text-sm text-slate-500">Data-driven analysis of student performance</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Risk Distribution Pie Chart */}
        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-slate-900">Risk Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {riskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Attendance Trend Line Chart */}
        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-slate-900">Attendance & Grade Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={attendanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px'
                    }} 
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="attendance" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6', strokeWidth: 2 }}
                    name="Attendance %"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="grade" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ fill: '#10b981', strokeWidth: 2 }}
                    name="Grade %"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Grade Distribution Bar Chart */}
        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-slate-900">Grade Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={gradeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="value" name="Students" radius={[4, 4, 0, 0]}>
                    {gradeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Risk Pattern Heatmap */}
        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-slate-900">Risk Pattern Heatmap</CardTitle>
            <p className="text-xs text-slate-500">Engagement intensity by day and time</p>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <div className="grid grid-cols-6 gap-1 h-full">
                <div className="col-span-1" />
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(day => (
                  <div key={day} className="text-xs text-slate-500 text-center font-medium">
                    {day}
                  </div>
                ))}
                {['8AM', '10AM', '12PM', '2PM', '4PM'].map(hour => (
                  <div key={hour} className="contents">
                    <div className="text-xs text-slate-500 flex items-center justify-end pr-2 font-medium">
                      {hour}
                    </div>
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(day => {
                      const dataPoint = heatmapData.find(d => d.day === day && d.hour === hour);
                      const value = dataPoint?.value || 0;
                      const intensity = value / 100;
                      return (
                        <div
                          key={`${day}-${hour}`}
                          className="rounded-md flex items-center justify-center text-xs font-medium transition-all hover:scale-110 cursor-pointer"
                          style={{
                            backgroundColor: `rgba(59, 130, 246, ${0.1 + intensity * 0.9})`,
                            color: intensity > 0.5 ? 'white' : '#1e293b'
                          }}
                          title={`${day} ${hour}: ${value}% engagement`}
                        >
                          {value}%
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
