import { useState } from 'react';
import { 
  Bell, 
  Mail, 
  MessageSquare, 
  Shield, 
  Users,
  Save,
  CheckCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

export function SettingsPanel() {
  const [settings, setSettings] = useState({
    emailAlerts: true,
    smsAlerts: false,
    pushNotifications: true,
    dailyDigest: true,
    weeklyReport: true,
    highRiskOnly: false,
    parentNotifications: true,
    counselorAutoAssign: true,
    dataEncryption: true,
    auditLogging: true
  });

  const [saved, setSaved] = useState(false);

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Settings</h2>
          <p className="text-sm text-slate-500">Configure alerts, notifications, and system preferences</p>
        </div>
        <Button onClick={handleSave} className={saved ? 'bg-emerald-600' : 'bg-blue-600'}>
          {saved ? (
            <>
              <CheckCircle className="h-4 w-4 mr-2" />
              Saved
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>

      {/* Notification Settings */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-600" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Mail className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <Label htmlFor="email-alerts" className="font-medium text-slate-900">Email Alerts</Label>
                <p className="text-sm text-slate-500">Receive risk alerts via email</p>
              </div>
            </div>
            <Switch 
              id="email-alerts" 
              checked={settings.emailAlerts}
              onCheckedChange={() => handleToggle('emailAlerts')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-green-50 rounded-lg">
                <MessageSquare className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <Label htmlFor="sms-alerts" className="font-medium text-slate-900">SMS Alerts</Label>
                <p className="text-sm text-slate-500">Get critical alerts via text message</p>
              </div>
            </div>
            <Switch 
              id="sms-alerts" 
              checked={settings.smsAlerts}
              onCheckedChange={() => handleToggle('smsAlerts')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-purple-50 rounded-lg">
                <Bell className="h-4 w-4 text-purple-600" />
              </div>
              <div>
                <Label htmlFor="push-notifications" className="font-medium text-slate-900">Push Notifications</Label>
                <p className="text-sm text-slate-500">Browser push notifications for real-time alerts</p>
              </div>
            </div>
            <Switch 
              id="push-notifications" 
              checked={settings.pushNotifications}
              onCheckedChange={() => handleToggle('pushNotifications')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Report Settings */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Mail className="h-5 w-5 text-emerald-600" />
            Report & Digest Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-amber-50 rounded-lg">
                <Mail className="h-4 w-4 text-amber-600" />
              </div>
              <div>
                <Label htmlFor="daily-digest" className="font-medium text-slate-900">Daily Digest</Label>
                <p className="text-sm text-slate-500">Receive daily summary of risk changes</p>
              </div>
            </div>
            <Switch 
              id="daily-digest" 
              checked={settings.dailyDigest}
              onCheckedChange={() => handleToggle('dailyDigest')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-indigo-50 rounded-lg">
                <Mail className="h-4 w-4 text-indigo-600" />
              </div>
              <div>
                <Label htmlFor="weekly-report" className="font-medium text-slate-900">Weekly Report</Label>
                <p className="text-sm text-slate-500">Comprehensive weekly analytics report</p>
              </div>
            </div>
            <Switch 
              id="weekly-report" 
              checked={settings.weeklyReport}
              onCheckedChange={() => handleToggle('weeklyReport')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-red-50 rounded-lg">
                <Bell className="h-4 w-4 text-red-600" />
              </div>
              <div>
                <Label htmlFor="high-risk-only" className="font-medium text-slate-900">High Risk Alerts Only</Label>
                <p className="text-sm text-slate-500">Only notify for high-risk student changes</p>
              </div>
            </div>
            <Switch 
              id="high-risk-only" 
              checked={settings.highRiskOnly}
              onCheckedChange={() => handleToggle('highRiskOnly')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Automation Settings */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Users className="h-5 w-5 text-purple-600" />
            Automation & Workflows
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-pink-50 rounded-lg">
                <Users className="h-4 w-4 text-pink-600" />
              </div>
              <div>
                <Label htmlFor="parent-notifications" className="font-medium text-slate-900">Parent Notifications</Label>
                <p className="text-sm text-slate-500">Automatically notify parents of high-risk status</p>
              </div>
            </div>
            <Switch 
              id="parent-notifications" 
              checked={settings.parentNotifications}
              onCheckedChange={() => handleToggle('parentNotifications')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-cyan-50 rounded-lg">
                <Users className="h-4 w-4 text-cyan-600" />
              </div>
              <div>
                <Label htmlFor="counselor-auto-assign" className="font-medium text-slate-900">Auto-Assign Counselors</Label>
                <p className="text-sm text-slate-500">Automatically assign counselors to high-risk students</p>
              </div>
            </div>
            <Switch 
              id="counselor-auto-assign" 
              checked={settings.counselorAutoAssign}
              onCheckedChange={() => handleToggle('counselorAutoAssign')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Shield className="h-5 w-5 text-emerald-600" />
            Security & Privacy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-emerald-50 rounded-lg">
                <Shield className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <Label htmlFor="data-encryption" className="font-medium text-slate-900">Data Encryption</Label>
                <p className="text-sm text-slate-500">Enable end-to-end encryption for all data</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">Required</Badge>
              <Switch 
                id="data-encryption" 
                checked={settings.dataEncryption}
                onCheckedChange={() => handleToggle('dataEncryption')}
                disabled
              />
            </div>
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Shield className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <Label htmlFor="audit-logging" className="font-medium text-slate-900">Audit Logging</Label>
                <p className="text-sm text-slate-500">Log all system access and changes</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">Required</Badge>
              <Switch 
                id="audit-logging" 
                checked={settings.auditLogging}
                onCheckedChange={() => handleToggle('auditLogging')}
                disabled
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
