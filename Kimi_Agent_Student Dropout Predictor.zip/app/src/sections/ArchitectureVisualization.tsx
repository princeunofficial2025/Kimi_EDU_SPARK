import { 
  Database, 
  Brain, 
  LayoutDashboard, 
  ArrowRight,
  Cloud,
  Shield,
  Zap,
  Code,
  Layers
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const architectureSteps = [
  {
    id: 'input',
    title: 'Data Input',
    description: 'Student data collection from multiple sources',
    icon: Database,
    color: 'blue',
    details: [
      'Attendance systems',
      'Gradebook APIs',
      'Behavior logs',
      'Engagement metrics'
    ]
  },
  {
    id: 'preprocessing',
    title: 'Preprocessing',
    description: 'Data cleaning and feature engineering',
    icon: Layers,
    color: 'indigo',
    details: [
      'Missing value imputation',
      'Outlier detection',
      'Feature scaling',
      'Data normalization'
    ]
  },
  {
    id: 'ml-model',
    title: 'ML Model',
    description: 'Random Forest & XGBoost ensemble',
    icon: Brain,
    color: 'purple',
    details: [
      'Risk score prediction',
      'Pattern recognition',
      'Anomaly detection',
      'Confidence scoring'
    ]
  },
  {
    id: 'prediction',
    title: 'Risk Prediction',
    description: 'Real-time dropout risk assessment',
    icon: Zap,
    color: 'amber',
    details: [
      'Risk categorization',
      'Trend analysis',
      'Alert generation',
      'Intervention mapping'
    ]
  },
  {
    id: 'dashboard',
    title: 'Dashboard',
    description: 'Educator-friendly insights & actions',
    icon: LayoutDashboard,
    color: 'emerald',
    details: [
      'Visual analytics',
      'Student profiles',
      'Alert management',
      'Report generation'
    ]
  }
];

const techStack = [
  { name: 'React', category: 'Frontend', color: 'blue' },
  { name: 'TypeScript', category: 'Language', color: 'blue' },
  { name: 'Tailwind CSS', category: 'Styling', color: 'cyan' },
  { name: 'Python', category: 'Backend', color: 'yellow' },
  { name: 'FastAPI', category: 'API', color: 'green' },
  { name: 'TensorFlow', category: 'ML', color: 'orange' },
  { name: 'Scikit-learn', category: 'ML', color: 'orange' },
  { name: 'PostgreSQL', category: 'Database', color: 'blue' },
  { name: 'Redis', category: 'Cache', color: 'red' },
  { name: 'Docker', category: 'DevOps', color: 'blue' },
  { name: 'Kubernetes', category: 'Orchestration', color: 'blue' },
  { name: 'GCP', category: 'Cloud', color: 'red' }
];

export function ArchitectureVisualization() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">System Architecture</h2>
          <p className="text-sm text-slate-500">End-to-end AI pipeline for dropout prediction</p>
        </div>
        <Badge className="bg-blue-100 text-blue-700 border-blue-200">
          <Code className="h-3 w-3 mr-1" />
          Production Ready
        </Badge>
      </div>

      {/* Architecture Flow */}
      <Card className="border-slate-200 overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-slate-900 to-slate-800 text-white">
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Data Flow Pipeline
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="relative">
            {/* Connection Line */}
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500 -translate-y-1/2 z-0" />
            
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 relative z-10">
              {architectureSteps.map((step, index) => {
                const Icon = step.icon;
                const colors: Record<string, string> = {
                  blue: 'bg-blue-500',
                  indigo: 'bg-indigo-500',
                  purple: 'bg-purple-500',
                  amber: 'bg-amber-500',
                  emerald: 'bg-emerald-500'
                };
                
                return (
                  <div key={step.id} className="relative">
                    <div className="bg-white rounded-xl border-2 border-slate-200 p-4 hover:border-blue-400 hover:shadow-lg transition-all duration-300 h-full">
                      <div className={`w-12 h-12 ${colors[step.color]} rounded-xl flex items-center justify-center mb-3 mx-auto`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <span className="text-xs font-bold text-slate-400">Step {index + 1}</span>
                          {index < architectureSteps.length - 1 && (
                            <ArrowRight className="h-4 w-4 text-slate-300 hidden lg:block" />
                          )}
                        </div>
                        <h4 className="font-semibold text-slate-900 text-sm">{step.title}</h4>
                        <p className="text-xs text-slate-500 mt-1">{step.description}</p>
                      </div>
                      <div className="mt-3 pt-3 border-t border-slate-100">
                        <ul className="space-y-1">
                          {step.details.map((detail, idx) => (
                            <li key={idx} className="text-xs text-slate-600 flex items-center gap-1">
                              <div className={`h-1.5 w-1.5 rounded-full ${colors[step.color]}`} />
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tech Stack */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900">Technology Stack</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {techStack.map((tech, index) => {
              const colors: Record<string, string> = {
                blue: 'bg-blue-50 text-blue-700 border-blue-200',
                cyan: 'bg-cyan-50 text-cyan-700 border-cyan-200',
                yellow: 'bg-yellow-50 text-yellow-700 border-yellow-200',
                green: 'bg-green-50 text-green-700 border-green-200',
                orange: 'bg-orange-50 text-orange-700 border-orange-200',
                red: 'bg-red-50 text-red-700 border-red-200'
              };
              
              return (
                <div
                  key={index}
                  className={`px-3 py-2 rounded-lg border ${colors[tech.color as keyof typeof colors]} hover:shadow-md transition-shadow cursor-default`}
                >
                  <p className="text-sm font-medium">{tech.name}</p>
                  <p className="text-xs opacity-70">{tech.category}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Security & Compliance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-emerald-200 bg-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <Shield className="h-5 w-5 text-emerald-600" />
              </div>
              <h4 className="font-semibold text-emerald-900">FERPA Compliant</h4>
            </div>
            <p className="text-sm text-emerald-700">
              Full compliance with student data privacy regulations. End-to-end encryption for all sensitive information.
            </p>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Zap className="h-5 w-5 text-blue-600" />
              </div>
              <h4 className="font-semibold text-blue-900">Real-time Processing</h4>
            </div>
            <p className="text-sm text-blue-700">
              Sub-second prediction latency with auto-scaling infrastructure. Handle 10,000+ concurrent users.
            </p>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Brain className="h-5 w-5 text-purple-600" />
              </div>
              <h4 className="font-semibold text-purple-900">94.7% Accuracy</h4>
            </div>
            <p className="text-sm text-purple-700">
              Validated ML model with continuous learning. Trained on 50,000+ student records across diverse demographics.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* API Endpoints */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900">API-First Design</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm overflow-x-auto">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <span className="text-green-400">GET</span>
                <span className="text-blue-400">/api/v1/students</span>
                <span className="text-slate-500">// List all students with risk scores</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-green-400">GET</span>
                <span className="text-blue-400">/api/v1/students/&#123;id&#125;/risk</span>
                <span className="text-slate-500">// Get individual risk assessment</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-amber-400">POST</span>
                <span className="text-blue-400">/api/v1/predict</span>
                <span className="text-slate-500">// Run prediction on new data</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-green-400">GET</span>
                <span className="text-blue-400">/api/v1/alerts</span>
                <span className="text-slate-500">// Fetch active alerts</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-amber-400">POST</span>
                <span className="text-blue-400">/api/v1/interventions</span>
                <span className="text-slate-500">// Create intervention record</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
