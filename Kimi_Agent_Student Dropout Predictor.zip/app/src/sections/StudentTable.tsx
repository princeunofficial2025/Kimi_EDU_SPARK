import { useState } from 'react';
import { 
  Search, 
  Filter, 
  ChevronDown, 
  ChevronUp, 
  MoreHorizontal,
  User,
  Mail,
  Phone,
  FileText
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Student } from '@/types';
import { interventions } from '@/data/mockData';

interface StudentTableProps {
  students: Student[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  riskFilter: 'all' | 'low' | 'medium' | 'high';
  setRiskFilter: (filter: 'all' | 'low' | 'medium' | 'high') => void;
  onSelectStudent: (student: Student) => void;
}

type SortField = 'name' | 'attendance' | 'averageGrade' | 'riskScore';
type SortDirection = 'asc' | 'desc';

export function StudentTable({ 
  students, 
  searchQuery, 
  setSearchQuery,
  riskFilter,
  setRiskFilter,
  onSelectStudent
}: StudentTableProps) {
  const [sortField, setSortField] = useState<SortField>('riskScore');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const sortedStudents = [...students].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    const modifier = sortDirection === 'asc' ? 1 : -1;
    return (aValue > bValue ? 1 : -1) * modifier;
  });

  const getRiskBadge = (category: string) => {
    switch (category) {
      case 'low':
        return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">Low Risk</Badge>;
      case 'medium':
        return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">Medium Risk</Badge>;
      case 'high':
        return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">High Risk</Badge>;
      default:
        return null;
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score <= 40) return 'text-emerald-600';
    if (score <= 70) return 'text-amber-600';
    return 'text-red-600';
  };

  const getRecommendations = (student: Student) => {
    if (student.riskCategory === 'low') {
      return interventions.filter(i => i.category === 'low');
    } else if (student.riskCategory === 'medium') {
      return interventions.filter(i => i.category === 'medium');
    }
    return interventions.filter(i => i.category === 'high');
  };

  return (
    <Card className="border-slate-200">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-lg font-semibold text-slate-900">Student Directory</CardTitle>
            <p className="text-sm text-slate-500">{students.length} students monitored</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search students..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-full sm:w-64"
              />
            </div>
            <Select value={riskFilter} onValueChange={(v) => setRiskFilter(v as any)}>
              <SelectTrigger className="w-32">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risks</SelectItem>
                <SelectItem value="low">Low Risk</SelectItem>
                <SelectItem value="medium">Medium Risk</SelectItem>
                <SelectItem value="high">High Risk</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th 
                  className="px-4 py-3 text-left text-xs font-semibold text-slate-600 cursor-pointer hover:bg-slate-100 transition-colors"
                  onClick={() => handleSort('name')}
                >
                  <div className="flex items-center gap-1">
                    Student
                    {sortField === 'name' && (
                      sortDirection === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-xs font-semibold text-slate-600 cursor-pointer hover:bg-slate-100 transition-colors"
                  onClick={() => handleSort('attendance')}
                >
                  <div className="flex items-center gap-1">
                    Attendance
                    {sortField === 'attendance' && (
                      sortDirection === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-xs font-semibold text-slate-600 cursor-pointer hover:bg-slate-100 transition-colors"
                  onClick={() => handleSort('averageGrade')}
                >
                  <div className="flex items-center gap-1">
                    Grade
                    {sortField === 'averageGrade' && (
                      sortDirection === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-xs font-semibold text-slate-600 cursor-pointer hover:bg-slate-100 transition-colors"
                  onClick={() => handleSort('riskScore')}
                >
                  <div className="flex items-center gap-1">
                    Risk Score
                    {sortField === 'riskScore' && (
                      sortDirection === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                    )}
                  </div>
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Risk Level</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sortedStudents.map((student) => (
                <tr 
                  key={student.id} 
                  className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                    student.riskCategory === 'high' ? 'bg-red-50/50' : ''
                  }`}
                  onClick={() => {
                    setSelectedStudent(student);
                    onSelectStudent(student);
                  }}
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-sm font-medium">
                        {student.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-900">{student.name}</p>
                        <p className="text-xs text-slate-500">{student.id} • Grade {student.grade}{student.section}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            student.attendance >= 90 ? 'bg-emerald-500' : 
                            student.attendance >= 75 ? 'bg-amber-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${student.attendance}%` }}
                        />
                      </div>
                      <span className="text-sm text-slate-600">{student.attendance}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${
                      student.averageGrade >= 80 ? 'text-emerald-600' : 
                      student.averageGrade >= 60 ? 'text-amber-600' : 'text-red-600'
                    }`}>
                      {student.averageGrade}%
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-bold ${getRiskScoreColor(student.riskScore)}`}>
                      {student.riskScore}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {getRiskBadge(student.riskCategory)}
                  </td>
                  <td className="px-4 py-3">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          setSelectedStudent(student);
                        }}>
                          <User className="h-4 w-4 mr-2" />
                          View Profile
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                          <Mail className="h-4 w-4 mr-2" />
                          Send Email
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                          <Phone className="h-4 w-4 mr-2" />
                          Call Parent
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                          <FileText className="h-4 w-4 mr-2" />
                          Generate Report
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>

      {/* Student Detail Dialog */}
      <Dialog open={!!selectedStudent} onOpenChange={() => setSelectedStudent(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {selectedStudent && (
                <>
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                    {selectedStudent.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p>{selectedStudent.name}</p>
                    <p className="text-sm font-normal text-slate-500">{selectedStudent.id}</p>
                  </div>
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              Detailed student risk assessment and intervention recommendations
            </DialogDescription>
          </DialogHeader>
          
          {selectedStudent && (
            <ScrollArea className="max-h-[60vh]">
              <div className="space-y-6 py-4">
                {/* Risk Score */}
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-slate-600">Risk Score</span>
                    <span className={`text-2xl font-bold ${getRiskScoreColor(selectedStudent.riskScore)}`}>
                      {selectedStudent.riskScore}/100
                    </span>
                  </div>
                  <Progress value={selectedStudent.riskScore} className="h-3" />
                  <div className="flex justify-between mt-1 text-xs text-slate-400">
                    <span>Low Risk</span>
                    <span>Medium Risk</span>
                    <span>High Risk</span>
                  </div>
                </div>

                {/* Key Metrics */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 rounded-lg p-3">
                    <p className="text-xs text-slate-500 mb-1">Attendance</p>
                    <p className="text-lg font-semibold text-slate-900">{selectedStudent.attendance}%</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-3">
                    <p className="text-xs text-slate-500 mb-1">Average Grade</p>
                    <p className="text-lg font-semibold text-slate-900">{selectedStudent.averageGrade}%</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-3">
                    <p className="text-xs text-slate-500 mb-1">Assignment Completion</p>
                    <p className="text-lg font-semibold text-slate-900">{selectedStudent.assignmentCompletion}%</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-3">
                    <p className="text-xs text-slate-500 mb-1">Engagement Score</p>
                    <p className="text-lg font-semibold text-slate-900">{selectedStudent.engagementScore}%</p>
                  </div>
                </div>

                {/* Recommendations */}
                <div>
                  <h4 className="text-sm font-semibold text-slate-900 mb-3">Recommended Interventions</h4>
                  <div className="space-y-3">
                    {getRecommendations(selectedStudent).map((intervention) => (
                      <div key={intervention.id} className="border rounded-lg p-3 bg-white">
                        <div className="flex items-center gap-2 mb-2">
                          <div className={`h-2 w-2 rounded-full ${
                            intervention.category === 'high' ? 'bg-red-500' :
                            intervention.category === 'medium' ? 'bg-amber-500' : 'bg-emerald-500'
                          }`} />
                          <p className="font-medium text-slate-900">{intervention.title}</p>
                        </div>
                        <p className="text-sm text-slate-600 mb-2">{intervention.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {intervention.actions.map((action, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {action}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact Info */}
                <div className="border-t pt-4">
                  <h4 className="text-sm font-semibold text-slate-900 mb-2">Contact Information</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Mail className="h-4 w-4" />
                      <span>{selectedStudent.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Phone className="h-4 w-4" />
                      <span>+1 (555) 000-0000</span>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}
