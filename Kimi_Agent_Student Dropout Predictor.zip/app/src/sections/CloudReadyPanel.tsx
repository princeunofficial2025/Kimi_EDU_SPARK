import { 
  Cloud, 
  Server, 
  Database, 
  Scale, 
  Globe, 
  Shield, 
  CheckCircle,
  ArrowRight,
  Zap,
  Settings,
  Layers,
  Cpu
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const cloudFeatures = [
  {
    title: 'Cloud Run Compatible',
    description: 'Containerized deployment with automatic scaling from zero to thousands of instances',
    icon: Server,
    color: 'blue',
    features: [
      'Serverless containers',
      'Pay-per-use pricing',
      'Automatic HTTPS',
      'Custom domains'
    ]
  },
  {
    title: 'BigQuery Integration',
    description: 'Native integration with Google BigQuery for large-scale analytics',
    icon: Database,
    color: 'green',
    features: [
      'Real-time data streaming',
      'ML model training',
      'Predictive analytics',
      'Custom dashboards'
    ]
  },
  {
    title: 'Auto-scaling Architecture',
    description: 'Horizontal pod autoscaling based on CPU, memory, and custom metrics',
    icon: Scale,
    color: 'purple',
    features: [
      'Scale to zero',
      'Scale to thousands',
      'Load balancing',
      'Health checks'
    ]
  },
  {
    title: 'API-First Design',
    description: 'RESTful and GraphQL APIs for seamless integration',
    icon: Zap,
    color: 'amber',
    features: [
      'OpenAPI specification',
      'Authentication & authz',
      'Rate limiting',
      'API versioning'
    ]
  },
  {
    title: 'School ERP Integration',
    description: 'Pre-built connectors for popular school management systems',
    icon: Layers,
    color: 'indigo',
    features: [
      'Canvas LMS',
      'Blackboard',
      'Google Classroom',
      'Custom SIS'
    ]
  },
  {
    title: 'Global CDN',
    description: 'Edge-cached content delivery for sub-100ms latency worldwide',
    icon: Globe,
    color: 'cyan',
    features: [
      '200+ edge locations',
      'DDoS protection',
      'SSL/TLS encryption',
      'Cache invalidation'
    ]
  }
];

const deploymentSteps = [
  { name: 'Container Build', status: 'complete', progress: 100 },
  { name: 'Security Scan', status: 'complete', progress: 100 },
  { name: 'Unit Tests', status: 'complete', progress: 100 },
  { name: 'Integration Tests', status: 'complete', progress: 100 },
  { name: 'Staging Deploy', status: 'complete', progress: 100 },
  { name: 'Production Deploy', status: 'in-progress', progress: 75 }
];

const complianceBadges = [
  { name: 'SOC 2 Type II', color: 'blue' },
  { name: 'FERPA', color: 'green' },
  { name: 'GDPR', color: 'purple' },
  { name: 'COPPA', color: 'amber' },
  { name: 'ISO 27001', color: 'indigo' }
];

export function CloudReadyPanel() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Google Cloud Ready</h2>
          <p className="text-sm text-slate-500">Enterprise-grade deployment infrastructure</p>
        </div>
        <Badge className="bg-blue-100 text-blue-700 border-blue-200">
          <Cloud className="h-3 w-3 mr-1" />
          GCP Optimized
        </Badge>
      </div>

      {/* Deployment Status */}
      <Card className="border-slate-200 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-lg">
                <Cpu className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Deployment Pipeline</h3>
                <p className="text-sm text-slate-400">Production deployment in progress</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-sm text-emerald-400">Active</span>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {deploymentSteps.map((step, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  {step.status === 'complete' ? (
                    <CheckCircle className="h-4 w-4 text-emerald-400" />
                  ) : (
                    <div className="h-4 w-4 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
                  )}
                  <span className="text-xs font-medium">{step.name}</span>
                </div>
                <Progress value={step.progress} className="h-1.5" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Cloud Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {cloudFeatures.map((feature, index) => {
          const Icon = feature.icon;
          const colors: Record<string, { bg: string; border: string; icon: string }> = {
            blue: { bg: 'bg-blue-50', border: 'border-blue-200', icon: 'text-blue-600' },
            green: { bg: 'bg-emerald-50', border: 'border-emerald-200', icon: 'text-emerald-600' },
            purple: { bg: 'bg-purple-50', border: 'border-purple-200', icon: 'text-purple-600' },
            amber: { bg: 'bg-amber-50', border: 'border-amber-200', icon: 'text-amber-600' },
            indigo: { bg: 'bg-indigo-50', border: 'border-indigo-200', icon: 'text-indigo-600' },
            cyan: { bg: 'bg-cyan-50', border: 'border-cyan-200', icon: 'text-cyan-600' }
          };
          const color = colors[feature.color];

          return (
            <Card key={index} className={`border ${color.border} ${color.bg} hover:shadow-lg transition-shadow`}>
              <CardContent className="p-5">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-white rounded-lg shadow-sm">
                    <Icon className={`h-5 w-5 ${color.icon}`} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-900">{feature.title}</h4>
                    <p className="text-sm text-slate-600 mt-1">{feature.description}</p>
                    <ul className="mt-3 space-y-1">
                      {feature.features.map((f, idx) => (
                        <li key={idx} className="text-xs text-slate-500 flex items-center gap-1">
                          <CheckCircle className="h-3 w-3 text-emerald-500" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Compliance & Security */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Shield className="h-5 w-5 text-emerald-600" />
            Security & Compliance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2 mb-4">
            {complianceBadges.map((badge, index) => {
              const colors: Record<string, string> = {
                blue: 'bg-blue-100 text-blue-700 border-blue-200',
                green: 'bg-emerald-100 text-emerald-700 border-emerald-200',
                purple: 'bg-purple-100 text-purple-700 border-purple-200',
                amber: 'bg-amber-100 text-amber-700 border-amber-200',
                indigo: 'bg-indigo-100 text-indigo-700 border-indigo-200'
              };
              return (
                <Badge key={index} className={`px-3 py-1 ${colors[badge.color]}`}>
                  <CheckCircle className="h-3 w-3 mr-1" />
                  {badge.name}
                </Badge>
              );
            })}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-50 rounded-lg p-4">
              <p className="text-sm font-medium text-slate-900">Data Encryption</p>
              <p className="text-xs text-slate-600 mt-1">AES-256 at rest, TLS 1.3 in transit</p>
            </div>
            <div className="bg-slate-50 rounded-lg p-4">
              <p className="text-sm font-medium text-slate-900">Access Control</p>
              <p className="text-xs text-slate-600 mt-1">RBAC with MFA support</p>
            </div>
            <div className="bg-slate-50 rounded-lg p-4">
              <p className="text-sm font-medium text-slate-900">Audit Logging</p>
              <p className="text-xs text-slate-600 mt-1">Complete activity tracking</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Infrastructure Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4 text-center">
            <p className="text-3xl font-bold text-blue-700">99.99%</p>
            <p className="text-sm text-blue-600">Uptime SLA</p>
          </CardContent>
        </Card>
        <Card className="border-emerald-200 bg-emerald-50">
          <CardContent className="p-4 text-center">
            <p className="text-3xl font-bold text-emerald-700">&lt;100ms</p>
            <p className="text-sm text-emerald-600">API Latency</p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-4 text-center">
            <p className="text-3xl font-bold text-purple-700">50K+</p>
            <p className="text-sm text-purple-600">Requests/sec</p>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-4 text-center">
            <p className="text-3xl font-bold text-amber-700">200+</p>
            <p className="text-sm text-amber-600">Edge Locations</p>
          </CardContent>
        </Card>
      </div>

      {/* CTA */}
      <Card className="border-slate-200 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold">Ready to deploy?</h3>
              <p className="text-sm text-blue-100">Get started with Google Cloud in minutes</p>
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" className="bg-white text-blue-600 hover:bg-blue-50">
                <Settings className="h-4 w-4 mr-2" />
                Configure
              </Button>
              <Button className="bg-blue-800 hover:bg-blue-900 text-white">
                Deploy Now
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
